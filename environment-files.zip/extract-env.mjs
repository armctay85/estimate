import fs from 'fs';

// List of environment variables to extract
const envVars = [
  'DATABASE_URL',
  'PGDATABASE',
  'PGHOST',
  'PGPASSWORD',
  'PGPORT',
  'PGUSER',
  'FORGE_CLIENT_ID',
  'FORGE_CLIENT_SECRET',
  'OPENAI_API_KEY',
  'XAI_API_KEY',
  'STRIPE_SECRET_KEY',
  'STRIPE_WEBHOOK_SECRET',
  'VITE_STRIPE_PUBLIC_KEY',
  'SESSION_SECRET',
  'REPLIT_DOMAINS',
  'REPL_ID'
];

// Create .env content
let envContent = '# EstiMate App Environment Variables\n';
envContent += '# Generated on: ' + new Date().toISOString() + '\n';
envContent += '# WARNING: This file contains sensitive information. Keep it secure!\n\n';

envVars.forEach(varName => {
  const value = process.env[varName];
  if (value) {
    envContent += `${varName}=${value}\n`;
  } else {
    envContent += `# ${varName}=not_set\n`;
  }
});

// Add NODE_ENV
envContent += '\n# Environment\n';
envContent += 'NODE_ENV=' + (process.env.NODE_ENV || 'development') + '\n';

// Write to file
fs.writeFileSync('.env.extracted', envContent);
console.log('✅ Environment variables extracted to .env.extracted');
console.log('⚠️  This file contains sensitive information - handle with care!');
